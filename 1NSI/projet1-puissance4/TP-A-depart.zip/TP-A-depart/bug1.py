prix_unitaire = 4
quantite = 3
total = prix_unitaire * quantité
print("Total à payer :", total, "euros")
