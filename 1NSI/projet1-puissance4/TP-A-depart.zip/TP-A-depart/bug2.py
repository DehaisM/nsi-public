def moyenne(notes):
    somme = 0
    for note in notes
        somme = somme + note
    return somme / len(notes)

print("Moyenne :", moyenne([12, 15, 9]))
