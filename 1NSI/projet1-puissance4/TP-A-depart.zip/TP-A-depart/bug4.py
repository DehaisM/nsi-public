def case(grille, i, j):
    return grille[i][j]

def coin_bas_droite(grille):
    return case(grille, len(grille), len(grille[0]))

plateau = [["a", "b", "c"],
           ["d", "e", "f"]]
print("Le coin en bas à droite contient :", coin_bas_droite(plateau))
