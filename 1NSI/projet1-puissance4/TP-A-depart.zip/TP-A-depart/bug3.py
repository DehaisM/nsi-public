age = input("Quel âge as-tu ? ")
print("L'an prochain, tu auras", age + 1, "ans")
