def creer_grille(nb_lignes, nb_colonnes):
    grille = []
    for i in range(nb_lignes):
        ligne = []
        for j in range(nb_colonnes):
            ligne.append(".")
        grille.append(ligne)
    return grille

def afficher(grille):
    for i in range(len(grille)):
        texte = ""
        for j in range(len(grille)):
            texte = texte + grille[i][j] + " "
        print(texte)

plateau = creer_grille(6, 7)
plateau[5][6] = "X"
afficher(plateau)
