def somme_jusqua(n):
    total = 0
    for i in range(n):
        total = total + i
    return total

resultat = somme_jusqua(5)
print("1 + 2 + 3 + 4 + 5 =", resultat)
