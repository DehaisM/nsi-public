def compter(liste, valeur):
    compteur = 0
    for element in liste:
        if element == valeur:
            compteur = compteur + 1
        return compteur

notes = [3, 1, 3, 3, 2]
print("Le 3 apparaît", compter(notes, 3), "fois")
