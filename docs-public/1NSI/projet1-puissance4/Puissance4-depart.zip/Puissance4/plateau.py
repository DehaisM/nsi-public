import constantes


def creer_grille():
    """Renvoie une nouvelle grille de constantes.LIGNES lignes
    et constantes.COLONNES colonnes, dont toutes les cases valent constantes.VIDE."""
    pass   # à compléter (étape 1)


def colonne_valide(grille, colonne):
    """Renvoie True si on peut jouer dans la colonne d'indice colonne, False sinon.
    On peut y jouer si cet indice existe (entre 0 et constantes.COLONNES - 1)
    et si la colonne n'est pas pleine."""
    pass   # à compléter (étape 2)


def jouer_coup(grille, colonne, pion):
    """Fait tomber pion dans la colonne d'indice colonne : il se place dans la case
    vide la plus basse de cette colonne. La grille est modifiée directement,
    la fonction ne renvoie rien. On suppose que la colonne n'est pas pleine."""
    pass   # à compléter (étape 2)


def grille_pleine(grille):
    """Renvoie True si la grille ne contient plus aucune case vide, False sinon."""
    pass   # à compléter (étape 4)


if __name__ == "__main__":
    # tester ici les fonctions de ce fichier, au fur et à mesure
    pass
