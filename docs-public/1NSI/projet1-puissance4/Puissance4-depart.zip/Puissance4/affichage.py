import constantes


def afficher_grille(grille):
    """Affiche la grille ligne par ligne, les cases étant séparées par un espace,
    puis, en dessous, les numéros des colonnes à partir de 1."""
    pass   # à compléter (étape 1)


if __name__ == "__main__":
    # tester ici les fonctions de ce fichier, au fur et à mesure
    pass
