import constantes


def alignement_horizontal(grille, pion):
    """Renvoie True si 4 pions égaux à pion se suivent sur une même ligne, False sinon."""
    pass   # à compléter (étape 3)


def alignement_vertical(grille, pion):
    """Renvoie True si 4 pions égaux à pion se suivent sur une même colonne, False sinon."""
    pass   # à compléter (étape 3)


def alignement_diagonal_descendant(grille, pion):
    """Renvoie True si 4 pions égaux à pion se suivent sur une diagonale
    qui descend de gauche à droite, False sinon."""
    # à compléter (étape 4) : en attendant, la fonction répond toujours False
    return False


def alignement_diagonal_montant(grille, pion):
    """Renvoie True si 4 pions égaux à pion se suivent sur une diagonale
    qui monte de gauche à droite, False sinon."""
    # à compléter (étape 4) : en attendant, la fonction répond toujours False
    return False


def victoire(grille, pion):
    """Renvoie True si 4 pions égaux à pion sont alignés dans une des 4 directions, False sinon."""
    pass   # à compléter (étape 3)


if __name__ == "__main__":
    # tester ici les fonctions de ce fichier, au fur et à mesure
    pass
