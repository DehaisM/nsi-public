# Les réglages du jeu : on les modifie ici, et tout le programme suit.

LIGNES = 6                           # nombre de lignes de la grille
COLONNES = 7                         # nombre de colonnes de la grille
VIDE = "."                           # symbole d'une case vide
PIONS = ["X", "O"]                   # pion du joueur 0, pion du joueur 1
NOMS = ["Joueur 1", "Joueur 2"]      # nom du joueur 0, nom du joueur 1
