import constantes
import plateau


def demander_colonne(grille, nom):
    """Demande au joueur nom dans quelle colonne il joue, sous la forme d'un numéro
    entre 1 et constantes.COLONNES, recommence tant que ce numéro ne correspond pas
    à une colonne valide, puis renvoie l'INDICE de cette colonne (entre 0 et
    constantes.COLONNES - 1). On suppose que le joueur tape bien un nombre."""
    pass   # à compléter (étape 2)


if __name__ == "__main__":
    # tester ici les fonctions de ce fichier, au fur et à mesure
    pass
