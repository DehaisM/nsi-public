# Puissance 4 à deux joueurs, dans le terminal.
# Fichiers du projet :
#   constantes.py  les réglages du jeu
#   plateau.py     créer la grille, jouer un coup, tester si une colonne est jouable ou la grille pleine
#   victoire.py    détecter un alignement de 4 pions
#   affichage.py   afficher la grille
#   saisie.py      demander au joueur la colonne où il joue
#   main.py        la boucle de jeu (ce fichier)

import constantes
import plateau
import victoire
import affichage
import saisie


def jouer():
    """Joue une partie complète de Puissance 4 à deux joueurs."""
    pass   # à compléter (étape 2)


if __name__ == "__main__":
    jouer()
